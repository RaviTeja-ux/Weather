import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LondonDaysComponent } from './london-days.component';

describe('LondonDaysComponent', () => {
  let component: LondonDaysComponent;
  let fixture: ComponentFixture<LondonDaysComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LondonDaysComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LondonDaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
