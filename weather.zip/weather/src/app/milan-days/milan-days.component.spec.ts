import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MilanDaysComponent } from './milan-days.component';

describe('MilanDaysComponent', () => {
  let component: MilanDaysComponent;
  let fixture: ComponentFixture<MilanDaysComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MilanDaysComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MilanDaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
