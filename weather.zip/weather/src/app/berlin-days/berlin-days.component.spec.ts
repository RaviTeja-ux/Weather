import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BerlinDaysComponent } from './berlin-days.component';

describe('BerlinDaysComponent', () => {
  let component: BerlinDaysComponent;
  let fixture: ComponentFixture<BerlinDaysComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BerlinDaysComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BerlinDaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
