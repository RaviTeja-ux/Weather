import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-rome-days',
  templateUrl: './rome-days.component.html',
  styleUrls: ['./rome-days.component.css']
})
export class RomeDaysComponent implements OnInit {ForecastData:any=[];
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.http.get("https://api.openweathermap.org/data/2.5/forecast?q=milan&appid=1f714b688b065326c9d47c8fe329f537")
    .subscribe((data)=>this.displayData(data));
  }
displayData(data:any)
 {
 this.ForecastData=data;
 this.ForecastData.date=(this.ForecastData.list.dt_txt);
 this.ForecastData.temp_celsius = (this.ForecastData.list.main.temp - 273.15).toFixed(0);
 this.ForecastData.sealevel=(this.ForecastData.list.main.sea_level);
}

}
