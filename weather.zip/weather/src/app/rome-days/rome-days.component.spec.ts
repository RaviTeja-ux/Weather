import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RomeDaysComponent } from './rome-days.component';

describe('RomeDaysComponent', () => {
  let component: RomeDaysComponent;
  let fixture: ComponentFixture<RomeDaysComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RomeDaysComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeDaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
