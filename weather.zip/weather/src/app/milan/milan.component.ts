import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-milan',
  templateUrl: './milan.component.html',
  styleUrls: ['./milan.component.css']
})
export class MilanComponent implements OnInit {

  WeatherData:any;
  constructor() { }
  ngOnInit(): void {
    this.WeatherData={
      main:{},
      isDay:true
    };
    this.getWeatherData();
    console.log(this.WeatherData)
  }
  getWeatherData(){
    fetch('https://api.openweathermap.org/data/2.5/weather?q=milan&appid=1f714b688b065326c9d47c8fe329f537')
.then(response=>response.json())
.then(data=>{this.setWeatherData(data);})  
//  let data=JSON.parse('{"coord":{"lon":-0.1257,"lat":51.5085},"weather":[{"id":804,"main":"Clouds","description":"overcast clouds","icon":"04d"}],"base":"stations","main":{"temp":291.13,"feels_like":291.1,"temp_min":289.43,"temp_max":292.65,"pressure":1019,"humidity":81},"visibility":10000,"wind":{"speed":5.14,"deg":70},"clouds":{"all":90},"dt":1630749616,"sys":{"type":2,"id":2006068,"country":"GB","sunrise":1630732691,"sunset":1630780876},"timezone":3600,"id":2643743,"name":"London","cod":200}')   
// this.setWeatherData(data);
  }
setWeatherData(data:any){
  this.WeatherData=data;
  let sunsetTime = new Date(this.WeatherData.sys.sunset*1000);
  this.WeatherData.sunset_time=sunsetTime.toLocaleTimeString();
  let sunriseTime = new Date(this.WeatherData.sys.sunrise*1000);
  this.WeatherData.sunrise_time=sunriseTime.toLocaleTimeString();
  let currentDate = new Date();
  this.WeatherData.isDay = (currentDate.getTime()< sunsetTime.getTime());
this.WeatherData.temp_celsius = (this.WeatherData.main.temp - 273.15).toFixed(0);
this.WeatherData.temp_min =(this.WeatherData.main.temp_min - 273.15).toFixed(0);
this.WeatherData.temp_max =(this.WeatherData.main.temp_max - 273.15).toFixed(0);
}
}
