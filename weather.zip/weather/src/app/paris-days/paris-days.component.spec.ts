import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParisDaysComponent } from './paris-days.component';

describe('ParisDaysComponent', () => {
  let component: ParisDaysComponent;
  let fixture: ComponentFixture<ParisDaysComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ParisDaysComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ParisDaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
