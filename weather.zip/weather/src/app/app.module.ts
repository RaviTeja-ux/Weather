import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { LondonComponent } from './london/london.component';
import { MilanComponent } from './milan/milan.component';
import { ParisComponent } from './paris/paris.component';
import { BerlinComponent } from './berlin/berlin.component';
import { RomeComponent } from './rome/rome.component';
import { ReactiveFormsModule } from '@angular/forms';
import { LondonDaysComponent } from './london-days/london-days.component';
import { BerlinDaysComponent } from './berlin-days/berlin-days.component';
import { MilanDaysComponent } from './milan-days/milan-days.component';
import { ParisDaysComponent } from './paris-days/paris-days.component';
import { RomeDaysComponent } from './rome-days/rome-days.component';

const appRoutes: Routes = [
  { path: "", component: LondonComponent},
  {path: "london", component:LondonComponent, children:[{path:"london-days",component:LondonDaysComponent}]},
  {path:"milan", component:MilanComponent, children:[{path:"milan-days",component:LondonDaysComponent}]},
  {path:"paris", component:ParisComponent, children:[{path:"paris-days",component:LondonDaysComponent}]},
  {path:"berlin", component:BerlinComponent, children:[{path:"berlin-days",component:BerlinDaysComponent}]},
  {path:"rome", component:RomeComponent, children:[{path:"rome-days",component:LondonDaysComponent}]},
];

@NgModule({
  declarations: [
    AppComponent,
    LondonComponent,
    MilanComponent,
    ParisComponent,
    BerlinComponent,
    RomeComponent,
    LondonDaysComponent,
    BerlinDaysComponent,
    MilanDaysComponent,
    ParisDaysComponent,
    RomeDaysComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
